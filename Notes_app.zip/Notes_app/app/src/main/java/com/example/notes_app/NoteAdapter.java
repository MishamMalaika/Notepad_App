package com.example.notes_app;

import android.app.AlertDialog;
import android.content.Context;
import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.notes_app.MainActivity;
import com.example.notes_app.R;

import java.util.ArrayList;

public class NoteAdapter extends RecyclerView.Adapter<NoteAdapter.NoteViewHolder> {

    Context c;
    ArrayList<singleNote> notes;
    OnSingleNoteClickListener onNoteClickListener;

    public interface OnSingleNoteClickListener{
        void onSingleNoteCLick(int position);
    }

    public NoteAdapter() {
    }
    public NoteAdapter(Context c, ArrayList<singleNote> notes, OnSingleNoteClickListener onNoteClickListener) {
        this.c = c;
        this.notes = notes;
        this.onNoteClickListener = onNoteClickListener;
    }

    @NonNull
    @Override
    public NoteViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(c).inflate(R.layout.one_note,parent,false);
        return new NoteViewHolder(v);

    }


    @Override
    public void onBindViewHolder(@NonNull NoteViewHolder holder, int position) {

        singleNote sn= notes.get(position);
        holder.tvtitleofnote.setText(sn.getTvtitleofnote());
        holder.tvthoughts.setText(sn.getTvthoughts());
        holder.itemView.setOnClickListener(v ->{ onNoteClickListener.onSingleNoteCLick(position);
        });
        holder.itemView.setOnLongClickListener(v -> {
            new AlertDialog.Builder(v.getContext()).setTitle("CONFIRM DELETION")
                    .setMessage("DO YOU WANT TO DELETE THE NOTE?")
                    .setPositiveButton("DELETE",((dialog, which) -> {
                        notes.remove(position);
                        notifyItemRemoved(position);
                        MainActivity.updateNotesCounting();


                    })
                    )
                    .setNegativeButton("CANCEL",null).show();
            return true;
        });

    }



    @NonNull


    public void udatingList(ArrayList<singleNote> updateNotes)
    {
        this.notes=updateNotes;
        notifyDataSetChanged();

    }


    public int getItemCount() {
       return notes.size();
    }

    public class NoteViewHolder extends RecyclerView.ViewHolder{
        TextView tvtitleofnote;
        TextView tvthoughts;
        public NoteViewHolder(View itemView)
        {
            super(itemView);
            tvtitleofnote=itemView.findViewById(R.id.tvtitleofnote);
            tvthoughts=itemView.findViewById(R.id.tvthoughts);

        }

    }
}

package com.example.notes_app;

import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements NoteAdapter.OnSingleNoteClickListener {

    TextView tvnotes;
    static TextView tvmore;
    static ArrayList<singleNote> notes = new ArrayList<>();
    RecyclerView rvnoteslist;
    FloatingActionButton fbplus;
    EditText etsearchnote;
    NoteAdapter Adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        init();

        fbplus.setOnClickListener((v) -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("DESIGN NEW NOTE");

            View view = LayoutInflater.from(this).inflate(R.layout.note_adding_design, null, false);
            builder.setView(view);

            builder.setPositiveButton("SAVE NOTE", (dialog, which) -> {
                TextInputEditText ettitle = view.findViewById(R.id.ettitle);
                TextInputEditText etthoughts = view.findViewById(R.id.etthoughts);
                String title = ettitle.getText().toString().trim();
                String thoughts = etthoughts.getText().toString().trim();

                if (title.isEmpty()) {
                    Toast.makeText(MainActivity.this, "YOU NEED TO FILL THE TITLE", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (thoughts.isEmpty()) {
                    Toast.makeText(MainActivity.this, "YOU NEED TO FILL THE DESCRIPTION", Toast.LENGTH_SHORT).show();
                    return;
                }

                notes.add(new singleNote(title, thoughts));
                updateNotesCounting();
                Adapter.notifyItemInserted(notes.size() - 1);
                Toast.makeText(MainActivity.this, "NOTE SAVED SUCCESSFULLY", Toast.LENGTH_SHORT).show();
            });

            builder.setNegativeButton("CANCEL", (dialog, which) -> dialog.dismiss());

            builder.show(); // ✅ THIS WAS MISSING
        });
    }

    void init() {
        tvnotes = findViewById(R.id.tvnotes);
        tvmore = findViewById(R.id.tvmore);
        rvnoteslist = findViewById(R.id.rvnoteslist);
        etsearchnote = findViewById(R.id.etsearchnote);
        fbplus = findViewById(R.id.fbplus);

        fbplus.bringToFront(); // ✅ Ensures FAB stays clickable

        // Sample notes
        notes.add(new singleNote("MONDAY", "Have a nice day:)"));
        notes.add(new singleNote("REMINDER", "ASSIGNMENT PENDING:("));
        notes.add(new singleNote("FRIDAY", "hello everyone"));
        notes.add(new singleNote("REMINDER", "Quiz on Thursday:)"));

        updateNotesCounting();

        Adapter = new NoteAdapter(this, notes, this);
        rvnoteslist.setLayoutManager(new LinearLayoutManager(this));
        rvnoteslist.setAdapter(Adapter);

        etsearchnote.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                filteringNotes(s.toString());
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        // Swipe to delete
        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView,
                                  @NonNull RecyclerView.ViewHolder viewHolder,
                                  @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                int position = viewHolder.getAdapterPosition();
                notes.remove(position);
                Adapter.notifyItemRemoved(position);
                updateNotesCounting();
                Toast.makeText(MainActivity.this, "NOTE HAS BEEN DELETED", Toast.LENGTH_SHORT).show();
            }
        });

        itemTouchHelper.attachToRecyclerView(rvnoteslist);
    }

    void filteringNotes(String query) {
        ArrayList<singleNote> filteredList = new ArrayList<>();
        for (singleNote note : notes) {
            if (note.getTvtitleofnote().toLowerCase().contains(query.toLowerCase())) {
                filteredList.add(note);
            }
        }
        Adapter.udatingList(filteredList);
    }

    void EditDialog(singleNote selectedNote, int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("EDIT NOTE IF YOU WANT:)");

        View view = LayoutInflater.from(this).inflate(R.layout.note_adding_design, null);

        if (view.getParent() != null) {
            ((ViewGroup) view.getParent()).removeView(view);
        }

        TextInputEditText ettitle = view.findViewById(R.id.ettitle);
        TextInputEditText etthoughts = view.findViewById(R.id.etthoughts);
        ettitle.setText(selectedNote.getTvtitleofnote());
        etthoughts.setText(selectedNote.getTvthoughts());

        builder.setView(view);

        builder.setPositiveButton("UPDATE NOTE", (dialog, which) -> {
            String title = ettitle.getText().toString().trim();
            String thoughts = etthoughts.getText().toString().trim();
            if (!title.isEmpty()) {
                selectedNote.setTvtitleofnote(title);
                selectedNote.setTvthoughts(thoughts);
                Adapter.notifyItemChanged(position);
                Toast.makeText(this, "YOUR NOTE HAS BEEN UPDATED", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("CANCEL", null);
        builder.show();
    }

    @Override
    public void onSingleNoteCLick(int position) {
        singleNote selectedNote = notes.get(position);
        EditDialog(selectedNote, position);
    }

    static void updateNotesCounting() {
        tvmore.setText("Only " + notes.size() + "? Write more!");
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {
        super.onPointerCaptureChanged(hasCapture);}}

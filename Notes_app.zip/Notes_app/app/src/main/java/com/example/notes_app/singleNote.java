package com.example.notes_app;

public class singleNote {
    String tvtitleofnote;
    String tvthoughts;

    public singleNote() {
    }

    public singleNote(String tvtitleofnote, String tvthoughts) {
        this.tvtitleofnote = tvtitleofnote;
        this.tvthoughts = tvthoughts;
    }

    public String getTvtitleofnote() {
        return tvtitleofnote;
    }

    public void setTvtitleofnote(String tvtitleofnote) {
        this.tvtitleofnote = tvtitleofnote;
    }

    public String getTvthoughts() {
        return tvthoughts;
    }

    public void setTvthoughts(String tvthoughts) {
        this.tvthoughts = tvthoughts;
    }
}

